package rockets.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class LaunchUnitTest {
    private Launch target;

    @BeforeEach
    public void setUp() {
        target = new Launch();
    }

    //@DisplayName("should throw exception when pass invalid date to setLaunchDate")
    //@ParameterizedTest
    //@CsvSource({"2018/02/12", "1995", "2018-02-12"})

    @DisplayName("should return true when pass right date to setLaunchDate")
    @ParameterizedTest
    @ValueSource( strings = {"2018-02-12"})
    public void shouldReturnTrueWhenSetLaunchDateRightDate(LocalDate date) {
        target.setLaunchDate(date);
        assertTrue(target.getLaunchDate().equals(date));
    }

    @DisplayName("should return true when pass right date to setLaunchDate")
    @ParameterizedTest
    @ValueSource( strings = {"asasd","2019"})
    public void shouldReturnTrueWhenSetLaunchDateWrongMessage(LocalDate date) {

        assertTrue(date instanceof LocalDate);
        //IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> target.setLaunchDate(date));
        //assertEquals("Error converting parameter at index 0: Failed to convert String \"2018/02/12\" to type java.time.LocalDate", exception.getMessage());
    }

}