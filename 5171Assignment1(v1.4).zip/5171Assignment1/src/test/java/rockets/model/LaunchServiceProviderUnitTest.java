package rockets.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LaunchServiceProviderUnitTest {
    private LaunchServiceProvider target;

    @BeforeEach
    public void setUp() {
        target = new LaunchServiceProvider("SpaceX",2002, "USA");
    }

    @DisplayName("should throw exception when pass null to LSP name")
    @Test
    public void shouldThrowExceptionWhenPassNullToLSPName() {
        NullPointerException exception= assertThrows(NullPointerException.class, () -> new LaunchServiceProvider(null,2002, "USA"));
        assertEquals("The validated object is null", exception.getMessage());
    }

    @DisplayName("should throw exception when pass null to LSP company")
    @Test
    public void shouldThrowExceptionWhenPassNullToLSPCompany() {
        NullPointerException exception= assertThrows(NullPointerException.class, () -> new LaunchServiceProvider("SpaceX",2002, null));
        assertEquals("The validated object is null", exception.getMessage());
    }

}