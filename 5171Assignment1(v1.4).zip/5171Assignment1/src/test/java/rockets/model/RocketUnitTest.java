package rockets.model;

import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;


import static org.junit.jupiter.api.Assertions.*;


class RocketUnitTest {
    private Rocket target;

    @BeforeEach
    public void setUp() {
        target = new Rocket("Atlas V 401","USA", "ULA");
    }

    @DisplayName("should throw exception when pass null to rocket name")
    @Test
    public void shouldThrowExceptionWhenPassNullToRocketName() {
        NullPointerException exception= assertThrows(NullPointerException.class, () -> new Rocket(null,"USA", "ULA"));
        assertEquals("Name cannot be null", exception.getMessage());
    }

    @DisplayName("should throw exception when pass null to rocket country")
    @Test
    public void shouldThrowExceptionWhenPassNullToRocketCountry() {
        NullPointerException exception= assertThrows(NullPointerException.class, () -> new Rocket("Atlas V 401",null, "ULA"));
        assertEquals("Country cannot be null", exception.getMessage());
    }

    @DisplayName("should throw exception when pass null to rocket manufacturer")
    @Test
    public void shouldThrowExceptionWhenPassNullToRocketManufacturer() {
        NullPointerException exception= assertThrows(NullPointerException.class, () -> new Rocket("Atlas V 401","USA", null));
        assertEquals("Manufacturer cannot be null", exception.getMessage());
    }

    @DisplayName("should return true when two rockets have same rocket basic information including name, country and manufacturer")
    @Test
    public void shouldReturnTrueWhenRocketsHaveSameBasicInformation() {
        Rocket anotherRocket = new Rocket("Atlas V 401","USA", "ULA");;
        assertTrue(target.equals(anotherRocket));
    }

    @DisplayName("should return false when two users have different rocket information including name, country and manufacturer")
    @ParameterizedTest(name = "{index} ==> name={0},country={1}, manufacturer={2}")
    @CsvSource({ "default,USA,ULA", "Atlas V 401,default,ULA","Atlas V 401,USA,default" })
    public void shouldReturnTrueWhenRocketsHaveDifferentBasicInformation(String name, String country, String manufacturer) {
        Rocket rocketExample = new Rocket(name,country,manufacturer);
        assertFalse(target.equals(rocketExample));
    }
}

