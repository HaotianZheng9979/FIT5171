package rockets.model;

import org.junit.jupiter.api.BeforeEach;

import static org.junit.jupiter.api.Assertions.*;

class RocketTest {

    @BeforeEach
    void setUp() {
    }
}