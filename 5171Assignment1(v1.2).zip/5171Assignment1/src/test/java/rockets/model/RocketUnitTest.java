package rockets.model;

import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import sun.nio.cs.US_ASCII;

import java.lang.reflect.Parameter;

import static jdk.nashorn.internal.objects.Global.print;
import static org.junit.jupiter.api.Assertions.*;


class RocketUnitTest {

    @DisplayName("should throw exception when pass null to Rocket name")
    @Test
    public void shouldThrowExceptionWhenPassNullToRocketName() {
        NullPointerException exception= assertThrows(NullPointerException.class, () -> new Rocket(null,"USA", "ULA"));
        assertEquals("Name cannot be null", exception.getMessage());
    }

    @DisplayName("should throw exception when pass null to Rocket name")
    @Test
    public void shouldThrowExceptionWhenPassNullToRocketCountry() {
        NullPointerException exception= assertThrows(NullPointerException.class, () -> new Rocket("Atlas V 401",null, "ULA"));
        assertEquals("Country cannot be null", exception.getMessage());
    }

    @DisplayName("should throw exception when pass null to Rocket name")
    @Test
    public void shouldThrowExceptionWhenPassNullToRocketManufacturer() {
        NullPointerException exception= assertThrows(NullPointerException.class, () -> new Rocket("Atlas V 401","USA", null));
        assertEquals("Manufacturer cannot be null", exception.getMessage());
    }
}

