package rockets.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LaunchServiceProviderTest {

    @Test
    void getName() {
    }
}