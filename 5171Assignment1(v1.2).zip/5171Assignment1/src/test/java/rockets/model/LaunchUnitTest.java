package rockets.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class LaunchUnitTest {
    private Launch target;

    @BeforeEach
    public void setUp() {
        target = new Launch();
    }

    @DisplayName("should throw exception when pass invalid date to setLaunchDate")
    @ParameterizedTest
    @ValueSource( strings = {"2018/02/12", "1995", "2018-02/12"})
    public void shouldThrowExceptionWhenSetLaunchDateInvalid(LocalDate date) {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> target.setLaunchDate(date));
        assertEquals("email cannot be null or empty", exception.getMessage());
    }

}